//
// Created by abou on 23/10/2019.
//

#ifndef BST_BST_H
#define BST_BST_H


#include "Node.h"

class BST {
public:
    Node *root;
    int count=0;


public:
    BST(Node *root);
    bool findKey(int keyp);
    bool isComplete();
    void placeNode( std::vector<std::pair <int,int> > &Nh, int h);
    int getHeight();
    int nbrNodes();
    int nbChildrenAtLevel(int h);
    void print();
    void printCordinates();
    bool isBST();
    Node *getRoot();
    Node *remove(int value);
    bool isFull();
    int isBST(Node *node);
    Node *find(int key);
    bool insert(int keyp);
    template <typename T,size_t N>
    bool insert(T (&tabKey)[N]);
    Node *getNodeInPosition(int x, int y);

private:
    /*Addiionnal function i choose to put taht private */
    int isBSTUtil(Node *node, int min, int max);
    Node *deletionProcess(Node *root, int data);
    int maxDepth(Node *node);
    Node* FindMin(Node *root);

};


#endif //BST_BST_H

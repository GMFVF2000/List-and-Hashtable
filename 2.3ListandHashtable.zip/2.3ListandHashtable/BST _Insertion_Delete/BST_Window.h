//
// Created by abou on 08/10/2019.
//

#ifndef BST_BST_WINDOW_H
#define BST_BST_WINDOW_H

#include <glutWindow.h>
#include "Node.h"
#include "BST.h"
#include <time.h>

class BST_Window : public GlutWindow{
    BST *root;
    Node *toInsert=new Node(110);
    void onStart() override;
    void onDraw() override;
    void onQuit() override;
    void BST_draw(BST * root);
    void onMouseMove(double cx,double cy) override;
    void onMouseDown(int button,double cx,double cy) override;


public:
    BST_Window(const string &title,BST *root,int argc, char **argv) : GlutWindow(argc, argv, title, 800, 800, FIXED),
                                                                           root(root) {}

    void BST_draw(Node *root);
    void initialize();
    Node* getNodeInPosition(double cx, double cy, Node *root);
    void removeNode(Node *root);

    void placeTop(Node root);

    void placeButtonTop(Node *root);

    bool insertTopButton(int button,int cx, int cy);

    bool getNodeInPositionAndDelete(double cx, double cy, Node *item);
};

        void BST_Window::onStart() {
            glClearColor(0.25,0.25,0.25,1.0);
            initialize();
            glPopMatrix();
        }
        void BST_Window::onQuit()
        {
        }
        void BST_Window::onDraw() {
            glPushMatrix();
            glColor3f(255,255,255);

            BST_draw(this->root->getRoot());
            placeButtonTop( this->toInsert);
            glPopMatrix();
        }
        void BST_Window::onMouseMove(double cx,double cy) {


        }

        void BST_Window::onMouseDown(int button,double cx,double cy){

            insertTopButton(button, cx, cy);

            getNodeInPositionAndDelete( cx, cy, root->getRoot());

            initialize();
            BST_draw(this->root->getRoot());


        }
        /**
         * function deleguete to do the rendering of windows
         * @param root
         */
        void BST_Window::BST_draw(Node* root){
            glColor3f(50,50,50);
            fillEllipse(root->getX(),root->getY(),40,40);
            glColor3f(0,0,255);
            box(root->getX()-50,root->getY()-20,10,40);
            glColor3f(255,0,0);
            box(root->getX()+40,root->getY()-20,10,40);

            glColor3f(0,0,0);
            drawText(root->getX(),root->getY()-3,to_string(root->key),ALIGN_CENTER);
            if(root->leftChild)
            {   line(root->getX(),root->getY(),root->leftChild->getX(),root->leftChild->getY());
            BST_draw(root->leftChild);}

            if(root->rightChild) {
                line(root->getX(), root->getY(), root->rightChild->getX(), root->rightChild->getY());
                BST_draw(root->rightChild);
            }
        }

       /**
        * initialize the coordinates of each node of BST
        */
    void BST_Window::initialize(){
        int h=root->getHeight();
        std::vector < std::pair<int,int> > Nh;
        for (int j = 0; j < h; ++j) {
            Nh.push_back(std::make_pair(root->nbChildrenAtLevel(j),0) );
        }
        root->placeNode(Nh, 0);

    }

  /**
     *
        @param cx axis x coordinates of mouse during the tap
 *      @param cy axis y coordinates of mouse during the tap
 *      @param item the root node
 *   * @return the pointer that content
     */

    Node* BST_Window::getNodeInPosition(double cx,double cy,Node *item){

    if((cx-item->getX())*(cx-item->getX())+(cy-item->getY())*(cx-item->getY())<=40*40){
        return item;
    }
    if(item->leftChild)
        getNodeInPosition(cx,cy,item->leftChild);
    if(item->rightChild)
        getNodeInPosition(cx,cy,item->rightChild);
    return nullptr;
}

/**
 *
 * @param cx axis x coordinates of mouse during the tap
 * @param cy axis y coordinates of mouse during the tap
 * @param item the root node
 * @return true if delete a node else false
 */
bool BST_Window::getNodeInPositionAndDelete(double cx, double cy, Node *item){

                if((cx-item->getX())*(cx-item->getX())+(cy-item->getY())*(cx-item->getY())<=40*40){
                    cout<< "item->key :"<< item->key << std::endl;
                    removeNode(item);
                    return true;
                }
        if(item->leftChild)
            getNodeInPositionAndDelete(cx,cy,item->leftChild);
        if(item->rightChild)
            getNodeInPositionAndDelete(cx,cy,item->rightChild);
        return false;
    }

        void BST_Window::removeNode(Node *toDelete){
            this->root->remove(toDelete->key);
        }

    void BST_Window::placeButtonTop(Node *item){
        glColor3f(0,255,0);
        fillEllipse(750,750,40,40);
        glColor3f(0,0,0);
        drawText(750,750-3,to_string(item->key),ALIGN_CENTER);

    }
#endif //BST_BST_WINDOW_H

bool BST_Window::insertTopButton(int button,int cx,int cy)
        {


            if((cx-750)*(cx-750)+(cy-750)*(cx-750)<=40*40 && button==0){
                root->insert(this->toInsert->key);
                this->toInsert->key=rand()%100;
                return true;
            }
            if(button!=0){
                this->toInsert->key=rand()%100;
            }
            return false;
        }
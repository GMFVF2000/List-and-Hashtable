#include <iostream>
#include "Node.h"
#include "BST_Window.h"
#include "BST.h"
#include <vector>



using namespace std;
int main(int argc, char **argv ) {
    std::cout << "Hello, World!" << std::endl;


    Node *root;
    Node *node1 = new Node(9);
    Node *node2= new Node(14);
    node1=new Node(11 , node1,node2);
    node2= new Node(6, new Node(4),new Node(7));
    node1=new Node(8,node2,node1);
    node2=new Node(31, nullptr, nullptr);
    node2=new Node(25, new Node(21),node2);
    root=new Node(16,node1,node2);


    BST *monArbre= new BST(root);

    monArbre->remove(16);
    monArbre->insert(100);
    /**
     * for test insertion with array lke and template


    int a[]={1,2,3,4,5};
    monArbre->root->insert(a);
  */
    BST_Window test("Test",monArbre,argc,argv);
    test.start();
     return 0;
}




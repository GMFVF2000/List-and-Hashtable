//
// Created by abou on 23/10/2019.
//

#include "BST.h"
#include<bits/stdc++.h>

BST::BST(Node *root) : root(root) {

}

bool BST:: findKey(int keyp)
{
    if(root->key < keyp)
        return root->rightChild != nullptr ? root->rightChild->findKey(keyp) : false;


    if(root->key > keyp)
        return root->leftChild != nullptr ? root->leftChild->findKey(keyp) : false;


    return true;
}

bool BST::isComplete() {
    {
        if (root == nullptr)
            return false;

        list<Node*> queue;
        queue.push_back(root);

        Node* front = nullptr;

        bool flag = false;

        while (queue.size())
        {
            front = queue.front();
            queue.pop_front();
      if (flag && (front->leftChild || front->rightChild))
                return false;
            if (front->leftChild == nullptr && front->rightChild)
                return false;

            if (front->leftChild)
                queue.push_back(front->leftChild);

            else
                flag = true;


            if (front->rightChild)
                queue.push_back(front->rightChild);
            else
                flag = true;
        }
        return true;
    }
}
    void BST::placeNode( std::vector<std::pair <int,int> > &Nh, int h){
        int H= Nh.size();

        cout<< "Taille vector: " <<Nh[3].second<< std::endl;


        root->x=800*((Nh[h].second+0.5)/Nh[h].first);
        root->y=800*(1-(h+0.5)/H);
        cout<< "X" <<root->x<< std::endl;
        cout<< "Y" <<root->y<< std::endl;

        //root->x=800*(Nh[h].second+0.5)/H;
        //root->y=800*(1-(h+0.5)/H);
        Nh[h]=std::make_pair(Nh[h].first,Nh[h].second+1);

        if(root->leftChild) root->leftChild->placeNode(Nh,h+1);
        if(root->rightChild) root->rightChild->placeNode(Nh,h+1);
    }

int BST::getHeight(){
    return maxDepth(root);
     //return 1+ std::max( (root->leftChild ? root->leftChild->getHeight(): 0 ) , (root->leftChild?root->leftChild->getHeight(): 0 )) ;
}
int BST::nbrNodes() {

        return 1+(root->leftChild?root->leftChild->nbrNodes():0)+
               (root->rightChild?root->rightChild->nbrNodes():0);

}
bool BST::isBST(){
    return this->root->isBST();
};
int BST::nbChildrenAtLevel(int h) {

        if(h==0) return 1;
        else{
            return  (root->leftChild ? root->leftChild->nbChildrenAtLevel(h-1):0)+
                    (root->rightChild ? root->rightChild->nbChildrenAtLevel(h-1):0);

        }

}

void BST::print() {
        if(root->leftChild) root->leftChild->print();
        std::cout << root->key << std::endl;
        if (root->rightChild) root->rightChild->print();
}
/**
 * @paragraph helpful function to display all coordinates of nodes in
 */
void BST::printCordinates() {
    if(root->leftChild) root->leftChild->printCordinate();
    std::cout << "Value of x: " << root->x << std::endl;
    std::cout << "Value of x: " << root->y << std::endl;
    if (root->rightChild) root->rightChild->printCordinate();
}



/**
 * test if the tree is full i.e each node have no children or two children.
 * @return true if that is full else false
 */
bool BST::isFull(){

    if (this->root->leftChild == NULL && this->root->rightChild == NULL)
        return true;

    if ((this->root->leftChild) && (this->root->rightChild))
        return this->root->leftChild->isFull() && this->root->rightChild->isFull();

    return false;

}

Node* BST::getRoot() {
    return root;
}

/**
 * @paragraph
 * Case One
   For remove the noed without children very easy. Clean the poi,ter forward this node and it's ok
   Case two
   For remove with a one child we must change the pointer to the child only
   Case three
   I search the miminum for a right subtree
   Find min in right-subtree
   Copy the value in targetted node
   Delete duplicate from right-subtree
   Case three bis
   Find max in left-subtree
   Copy the value in targetted node
   Delete duplicate from left-subtree
 * @param root the root node of BST
 * @param value the value of node that we want to delete
 * @return
 */
Node *BST::remove(int value){
    return deletionProcess(this->getRoot(), value);
}

Node* BST::deletionProcess(Node *root, int data)  {
    if (root == nullptr) {
        return nullptr;
    }
    if (data < root->key) {  // data is in the left sub tree.
        root->leftChild = deletionProcess(root->leftChild, data);
    } else if (data > root->key) { // data is in the right sub tree.
        root->rightChild = deletionProcess(root->rightChild, data);
    } else {
        // case 1: no children
        if (root->leftChild == nullptr && root->rightChild == nullptr) {
            delete (root); // wipe out the memory, in C, use free function
            root = nullptr;
        }
            // case 2: one child (right)
        else if (root->leftChild == nullptr) {
            Node *temp = root; // save current node as a backup
            root = root->rightChild;
            delete temp;
        }
            // case 3: one child (left)
        else if (root->rightChild == nullptr) {
            Node *temp = root; // save current node as a backup
            root = root->leftChild;
            delete temp;
        }
            // case 4: two children
        else {
            Node *temp = FindMin(root->rightChild); // find minimal value of right sub tree
            root->key = temp->key; // duplicate the node
            root->rightChild = deletionProcess(root->rightChild, temp->key); // delete the duplicate node
        }
    }
    return root; // parent node can update reference
}

Node* BST::FindMin(Node *root) {
    if (root == nullptr) {
        return nullptr; // or undefined.
    }
    if (root->leftChild != nullptr) {
        return FindMin(root->leftChild); // left tree is smaller
    }
    return root;
}

int BST::isBST(Node* node)
{
    return(isBSTUtil(node, INT_MIN, INT_MAX));
}
/**
 * @paragraph additionnal function to do very simpliying the test for Bst structure
 * @param node the root node to check if bst.
 * @param min the boundary lower
 * @param max the boundary upper
 * @return true if it's bst else false
 */
int BST::isBSTUtil(Node* node, int min, int max)
{
    /* an empty tree is BST */
    if (node==NULL)
        return 1;

    /* false if this node violates
    the min/max constraint */
    if (node->key < min || node->key > max)
        return 0;

    /* otherwise check the subtrees recursively,
    tightening the min or max constraint */
    return
            isBSTUtil(node->leftChild, min, node->key-1) && // Allow only distinct values
            isBSTUtil(node->rightChild, node->key+1, max); // Allow only distinct values
}


int BST::maxDepth(Node* node)
{
    if (node == nullptr)
        return 0;
    else
    {
        int l = maxDepth(node->leftChild);

        int r = maxDepth(node->rightChild);
     if (l > r)
            return(l + 1);
        else return(r + 1);
    }
}
/**
 *
 @param keyp value to search in the tree
 * @return true if it's found else false
 */
Node * BST::find(int key){
    return root->find(key);
}
/**
 *
 * @param keyp value to insert in the tree
 * @return true if inssertion process is ok else false
 */
bool BST::insert(int keyp){
    if(this->root->key < keyp)
        if (this->root->rightChild == nullptr)
        {
            Node *temp=new Node(keyp, nullptr, nullptr);
            this->root->rightChild=temp;
            return true;
        }else{
            return this->root->rightChild->insert(keyp);
        }
    if(this->root->key > keyp)
        if( this->root->leftChild == nullptr)
        {
            Node *temp=new Node(keyp, nullptr, nullptr);
            this->root->leftChild=temp;
            return true;
        }else{
            return this->root->leftChild->insert(keyp);
        }
    return false;
}
/**
 *
 * @tparam T
 * @tparam N the number of item in the array
 * @param tabKey
 * @return
 */
template <typename T,size_t N>
bool BST::insert(T (&tabKey)[N])
{
       this->root->insert(tabKey);
    return true;
}



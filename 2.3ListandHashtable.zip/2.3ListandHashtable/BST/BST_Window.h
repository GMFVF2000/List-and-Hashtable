//
// Created by abou on 08/10/2019.
//

#ifndef BST_BST_WINDOW_H
#define BST_BST_WINDOW_H

#include <glutWindow.h>
#include "Node.h"
#include "BST.h"

class BST_Window : public GlutWindow{
    BST *root;
    void onStart() override;
    void onDraw() override;
    void onQuit() override;
    void BST_draw(BST * root);
    void onMouseMove(double cx,double cy) override;
    void onMouseDown(int button,double cx,double cy) override;


public:
    BST_Window(const string &title,BST *root,int argc, char **argv) : GlutWindow(argc, argv, title, 800, 800, FIXED),
                                                                           root(root) {}

    void BST_draw(Node *root);
};

        void BST_Window::onStart() {

            glClearColor(0.25,0.25,0.25,1.0);
            int h=root->getHeight();
            std::vector < std::pair<int,int> > Nh;
            for (int j = 0; j < h; ++j) {
                Nh.push_back(std::make_pair(root->nbChildrenAtLevel(j),0) );
            }
            root->placeNode(Nh, 0);
            glPopMatrix();
        }
        void BST_Window::onQuit()
        {
        }
        void BST_Window::onDraw() {

            glPushMatrix();
            glColor3f(255,255,255);
            BST_draw(root->getRoot());
            glPopMatrix();

        }
        void BST_Window::onMouseMove(double cx,double cy) {

        }

        void BST_Window::onMouseDown(int button,double cx,double cy){

        }

        void BST_Window::BST_draw(Node* root){
            glColor3f(50,50,50);
            fillEllipse(root->getX(),root->getY(),40,40);
            glColor3f(0,0,255);
            box(root->getX()-50,root->getY()-20,10,40);
            glColor3f(255,0,0);
            box(root->getX()+40,root->getY()-20,10,40);

            glColor3f(0,0,0);
            drawText(root->getX(),root->getY()-3,to_string(root->key),ALIGN_CENTER);
            if(root->leftChild)
            {   glColor3f(0,0,255);
                line(root->getX(),root->getY(),root->leftChild->getX(),root->leftChild->getY());
                BST_draw(root->leftChild);
            }

            if(root->rightChild) {
                glColor3f(255,0,0);
                line(root->getX(), root->getY(), root->rightChild->getX(), root->rightChild->getY());
                BST_draw(root->rightChild);
            }
        }

#endif //BST_BST_WINDOW_H
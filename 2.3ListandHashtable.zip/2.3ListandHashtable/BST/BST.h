//
// Created by abou on 23/10/2019.
//

#ifndef BST_BST_H
#define BST_BST_H


#include "Node.h"

class BST {
public:
    Node *root;
    int count=0;
public:
    BST(Node *root);
    bool findKey(int keyp);
    bool isComplete();
    void placeNode( std::vector<std::pair <int,int> > &Nh, int h);


    int getHeight();
    int nbrNodes();
    int nbChildrenAtLevel(int h);
    void print();
    void printCordinates();
    int countnodes(Node *root);
  //  bool isBST();

    Node *getRoot();

    int isBST();
    /**
     * Additional funtion to do that more effiency
     * @param node the root node for the first calling
     * @param min the boundary that we put to the verify the left part of tree according to each node
     * @param max the boundary that we put to the verify the left part of tree according to each node
     * @return 0 if node doesn't verify bst rule else 1.
     */
    bool isFull();
private:
    int isBSTUtil(Node *node, int min, int max);

    int maxDepth(Node *node);

};


#endif //BST_BST_H

#include <iostream>
#include "Node.h"
#include "BST_Window.h"
#include "BST.h"
#include <vector>



using namespace std;
int main(int argc, char **argv ) {
    std::cout << "Hello, World!" << std::endl;


    Node *root;
    Node *node1 = new Node(9);
    Node *node2= new Node(14);
    Node *node22;
    node1=new Node(11 , node1,node2);
    node2= new Node(7);
    node1=new Node(8,node2,node1);
    node22=new Node(31, nullptr, new Node(46));
    node2=new Node(25, new Node(21),node22);
    root=new Node(16,node1,node2);
    BST *monArbre= new BST(root);
    /**
     * Question 7
     */
    /*
    if(monArbre->isFull())
       cout<<"it's full"<< std::endl;
     else
       cout<< "It is not full"<<std::endl;
    */
     /**
      * addind the value 28
     */
     /* node22->leftChild=new Node(30);
    if(monArbre->isFull())
        cout<<"it's full"<< std::endl;
    else
        cout<< "It is not full"<<std::endl;
    */
     if(monArbre->isBST()){
         cout<<"it is bst";
     }
    monArbre->print();
    cout<<"Number of nodes: "<< monArbre->nbrNodes()<< std::endl;
    for (int i = 0; i < monArbre->getHeight(); ++i) {
        cout<<"Number of nodes at height "<< i << "= "<<monArbre->nbChildrenAtLevel(i)<< std::endl;
    }
     BST_Window test("Test",monArbre,argc,argv);
   test.start();


    /**
     * Question 9 insertion of figure 2.8
     */
   /* Node *left11 =new Node(14,new Node(12), nullptr);
    Node * left1=new Node(8,new Node(7), left11);
    Node * left111=new Node(63,new Node(55), nullptr);
    Node * right111=new Node(83, nullptr,new Node(94));
    Node * right11= new Node(68,left111,right111);
    Node * right1=new Node(54,new Node(35),right11);
    Node * root1=new Node(16,left1,right1);
    BST * bst28=new BST(root1);

    if(bst28->isBST()){
        cout << "The figure 2.8 is Bst "<< std::endl;
    } else{
        cout << "The figure 2.8 isn't Bst "<< std::endl;

    }
    if(bst28->isFull()){
        cout << "The figure 2.8 is Full " << std::endl;
    } else{
        cout << "The figure 2.8 isn't Full "<< std::endl;

    }

    if(bst28->isComplete()){
        cout << "The figure 2.8 is Complete "<< std::endl;
    } else{
        cout << "The figure 2.8 isn't Complete "<< std::endl;

    }
*/
  // BST_Window bstWindow28("Test",bst28,argc,argv);
    //bstWindow28.start();
 /*   if(bst28->findKey(14)){
        cout<<"J'ai trouvé 14";
    };*/
   // root1->print();

    return 0;
}




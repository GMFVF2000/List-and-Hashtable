//
// Created by abou on 23/09/2019.
//

#ifndef BST_NODE_H
#define BST_NODE_H


#include <iostream>
#include <algorithm>
#include <vector>
#include <glutWindow.h>
#include <stack>
#include <queue>
#include <list>
using namespace std;



class Node {
    Node* parent;

public:

   Node(int k):key(k),leftChild(nullptr),rightChild(nullptr),parent(nullptr){

    }
    /**
     *
     * @param k
     * @param lc
     * @param rc
     */
    Node(int k, Node* lc, Node *rc){
        key=k;
        leftChild=lc;
        rightChild=rc;
        parent= nullptr;
        if(leftChild) leftChild->parent=this;
        if(rightChild) rightChild->parent=this;

    }
    /**
     * @brief the number of element of nodes is 1 (me) +
     * the number of left children +
     * the number of right children
     * @return the number of children
     */
    int nbrNodes(){
        return 1+(leftChild?leftChild->nbrNodes():0)+
                (rightChild?rightChild->nbrNodes():0);
    }

    void print(){
        if(leftChild) leftChild->print();
        std::cout <<"("<< key <<")"<< std::endl;
        if (rightChild) rightChild->print();
     }
    void printCordinate(){
        if(leftChild) leftChild->printCordinate();
        std::cout << "Value of x: " << x << std::endl;
        std::cout << "Value of y: " << y << std::endl;
        if (rightChild) rightChild->printCordinate();
    }
    int nbChildrenAtLevel(int h){

        if(h==0) return 1;
        else{
            return  (leftChild ? leftChild->nbChildrenAtLevel(h-1):0)+
                    (rightChild ? rightChild->nbChildrenAtLevel(h-1):0);

        }
    }
    void placeNode( std::vector<std::pair <int,int> > &Nh, int h){
        int H= Nh.size();

       x=800*((Nh[h].second+0.5)/Nh[h].first);
        y=800*(1-(h+0.5)/H);
        Nh[h].second++;

        if(leftChild) leftChild->placeNode(Nh,h+1);
        if(rightChild) rightChild->placeNode(Nh,h+1);
    }



    float getX() const {
        return x;
    }

    float getY() const {
        return y;
    }

    Node* leftChild;
    Node* rightChild;
    int key;
    float x;
    float y;
public:
    Node *getLeftChild() const {
        return leftChild;
    }

    Node *getRightChild() const {
        return rightChild;
    }

    Node *getParent() const {
        return parent;
    }
    bool isBST(){

        if (this->leftChild != NULL && this->leftChild->key > this->key)
            return 0;
        if (this->rightChild != NULL && this->rightChild->key < this->key)
            return 0;
           if(leftChild!=NULL )
                if (!leftChild->isBST())
                return 0;
            if(rightChild!=NULL)if(!rightChild->isBST())
                    return 0;
        return 1;
    }

    bool isFull(){

        if (this->leftChild == NULL && this->rightChild == NULL)
            return true;

        if ((this->leftChild) && (this->rightChild))
            return this->leftChild->isFull() && this->rightChild->isFull();

      return false;

    }


    bool findKey(int keyp)
    {

            if(this->key < keyp)
                return rightChild != nullptr ? rightChild->findKey(keyp) : false;


            if(this->key > keyp)
                return leftChild != nullptr ? leftChild->findKey(keyp) : false;
            return true;
    }


    int getKey() const {
        return key;
    }

    void setParent(Node *parent) {
        Node::parent = parent;
    }

    void setLeftChild(Node *leftChild) {
        Node::leftChild = leftChild;
    }

    void setRightChild(Node *rightChild) {
        Node::rightChild = rightChild;
    }

    void setKey(int key) {
        Node::key = key;
    }

    void setX(float x) {
        Node::x = x;
    }

    void setY(float y) {
        Node::y = y;
    }

};


#endif //BST_NODE_H

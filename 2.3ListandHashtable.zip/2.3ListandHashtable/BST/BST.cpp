//
// Created by abou on 23/10/2019.
//

#include "BST.h"
#include<bits/stdc++.h>

BST::BST(Node *root) : root(root) {

}
/**
 * @details  it is a recurvive function method.
 * @return int give the number of nodes in the BST
 */


int BST::nbrNodes() {

    return 1+(root->leftChild?root->leftChild->nbrNodes():0)+
           (root->rightChild?root->rightChild->nbrNodes():0);

}


/**
 * @details give the number of levels in the BST
 * @return
 */
int BST::getHeight(){

    return maxDepth(root);
   // return 1+ std::max( (root->leftChild ? root->leftChild->getHeight(): 0 ) , (root->leftChild?root->leftChild->getHeight(): 0 )) ;
}
int BST::maxDepth(Node* node)
{
    if (node == nullptr)
        return 0;
    else
    {
        /* compute the depth of each subtree */
        int l = maxDepth(node->leftChild);
        int r = maxDepth(node->rightChild);

        /* use the larger one */
        if (l > r)
            return(l + 1);
        else return(r + 1);
    }
}

/**
 *
 * @param h the height
 * @return the number of the children present in this height
 */
int BST::nbChildrenAtLevel(int h) {

    if(h==0) return 1;
    else{
        return  (root->leftChild ? root->leftChild->nbChildrenAtLevel(h-1):0)+
                (root->rightChild ? root->rightChild->nbChildrenAtLevel(h-1):0);

    }

}

/*
 * function to initialize the coordinates of each nodes in windows.
 * it is a recursive approach
 */



    void BST::placeNode( std::vector<std::pair <int,int> > &Nh, int h){
        int H= Nh.size();
         root->x=800*((Nh[h].second+0.5)/Nh[h].first);
        root->y=800*(1-(h+0.5)/H);
        Nh[h]=std::make_pair(Nh[h].first,Nh[h].second+1);
        if(root->leftChild) root->leftChild->placeNode(Nh,h+1);
        if(root->rightChild) root->rightChild->placeNode(Nh,h+1);
    }

bool BST:: findKey(int keyp)
{
    if(root->key < keyp)
        return root->rightChild != nullptr ? root->rightChild->findKey(keyp) : false;


    if(root->key > keyp)
        return root->leftChild != nullptr ? root->leftChild->findKey(keyp) : false;


    return true;
}
/**
 *@details
 * @return true if BST is complete else false.
 */
bool BST::isComplete() {
    {
        if (root == nullptr)
            return false;

        list<Node*> queue;
        queue.push_back(root);
        Node* front = nullptr;
        bool flag = false;
        while (queue.size())
        {
            front = queue.front();
            queue.pop_front();
            if (flag && (front->leftChild || front->rightChild))
                return false;
            if (front->leftChild == nullptr && front->rightChild)
                return false;
            if (front->leftChild)
                queue.push_back(front->leftChild);
            else
                flag = true;
            if (front->rightChild)
                queue.push_back(front->rightChild);
            else
                flag = true;
        }

        return true;
    }
}



void BST::print() {
        if(root->leftChild) root->leftChild->print();
        std::cout << "("<<root->key<<")"<< std::endl;
        if (root->rightChild) root->rightChild->print();
}

void BST::printCordinates() {
    if(root->leftChild) root->leftChild->printCordinate();
    std::cout << "Value of x: " << root->x << std::endl;
    std::cout << "Value of x: " << root->y << std::endl;
    if (root->rightChild) root->rightChild->printCordinate();
}

int BST::countnodes(Node *root)

{
    if(root != NULL)
    {
        countnodes(root->leftChild);
        count++;
        countnodes(root->rightChild);
    }
    return count;

}

/**@paragraph
 * My solution looks at each node only once.
 * The trick is to write a utility helper function isBSTUtil(node* node, int min, int max)
 * that traverses down the tree keeping track of the narrowing min and max allowed values as it goes,
 * looking at each node only once.
 * The initial values for min and max should be INT_MIN and INT_MAX — they narrow from there.
 * @return 0 if it's not a bst else another value
 */
int BST::isBST()
{
    return(isBSTUtil(this->getRoot(), INT_MIN, INT_MAX));
}
/**
 *
 * @param node the ode where we want to start to test if the subtree is a BST
 * @param min the boundary lower to test if te proprieties of Bst is verify on a set of nodes
 * @param max the boundary upper to test if te proprieties of Bst is verify on a set of nodes
 * @return 0 if it's not a bst else another value
 */
int BST::isBSTUtil(Node* node, int min, int max)
{
    /* an empty tree is BST */
    if (node==NULL)
        return 1;

    /* false if this node violates
    the min/max constraint */
    if (node->key < min || node->key > max)
        return 0;

    /* otherwise check the subtrees recursively,
    tightening the min or max constraint */
    return
            isBSTUtil(node->leftChild, min, node->key-1) && // Allow only distinct values
            isBSTUtil(node->rightChild, node->key+1, max); // Allow only distinct values
}

Node *BST::getRoot() {
    return root;
}

bool BST::isFull(){

    if (this->root->leftChild == NULL && this->root->rightChild == NULL)
        return true;

    if ((this->root->leftChild) && (this->root->rightChild))
        return this->root->leftChild->isFull() && this->root->rightChild->isFull();

    return false;
}
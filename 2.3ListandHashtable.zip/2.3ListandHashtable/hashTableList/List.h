//
// Created by abou on 25/09/2019.
//

#ifndef HASHTABLE_LIST_H
#define HASHTABLE_LIST_H

#include <cstring>
#include "constants.h"
#include <vector>

template <class T>
class List {
public:
    T *value;
    List *next;
public:
    List (T * value)
            :value(value){
        next= nullptr;
    }

    operator int() const {
        int hash = 0;
        for (char a: value->surname) {
            hash += (int) a;
        }
        return hash % hash_size;
    }


public:

   bool insert( T *item ) {
       if ( value == nullptr ) {
           value = item;
           next = nullptr;
       } else {


           if ( next == nullptr ) {

               List <T> *tmp = new List <T>( item );
               next = tmp;
           } else {
               next->insert( item );
           }
       }
       return true;
   };


    bool insertOconstant( T *item ) {
        if ( value == nullptr ) {
            value = item;
            next = nullptr;
        } else {


            if ( next == nullptr ) {

                List <T> *tmp = new List <T>( item );

                value =tmp;

                next = tmp;
            } else {
                next->insert( item );
            }
        }
        return true;
    };


    int find(List<T> *fnd){

        if(std::strcmp(fnd->value->surname.c_str(),value->surname.c_str())==0)
        {
            return true;
        }

        if(next!= nullptr)
        {
            return next->find(fnd);
        }
        return false;

    }

    int find(List<T> *fnd,std::vector<Student> &res ){

        if(std::strcmp(fnd->value->surname.c_str(),value->surname.c_str())==0)
        {
            res.push_back(*value);
        }

        if(next!= nullptr)
        {
             next->find(fnd,res);
        }
        return res.size();

    }


    /**
     *
     * @param out
     * @param p
     * @return the os stream such as cout operator
     */

    friend std::ostream& operator << ( std::ostream &out, const List<T> &p){

        out << p.value->name +" "+p.value->surname+" ("+ std::to_string(p.value->hash_value)+ ") |";
        if(p.next!= nullptr){
            out << *p.next;

        }
        return out;
    }
    /**
     *
     * @param first
     * @param second
     * @return call overriding of operator == in Student class beacuse i also overided operator == for Student class
     */
    friend bool operator == ( List<T> &first, const List<T> &second){

        return first.value == second.value?true:false;
    }
};

#endif //HASHTABLE_LIST_H

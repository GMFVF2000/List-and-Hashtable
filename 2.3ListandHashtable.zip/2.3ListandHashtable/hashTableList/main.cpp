#include <iostream>
#include "Student.h"
#include "MyFactory.h"
#include "List.h"

int main() {
    string absolutePath = workPath + "list_students.csv";

    MyFactory<List<Student>> test(absolutePath);


    //For single insertion process test.
    Student *nwx = new Student("SANOU", "Issiaka", "Professeur");
    test.insert(nwx);

    nwx = new Student("Frederic", "LASSABE", "PhD");
    test.insert(nwx);

    nwx = new Student("Philippe", "CANALDA", "PhD");
    test.insert(nwx);


    nwx = new Student("Kane", "Issiaka", "Professeur");
    test.insert(nwx);
    test.print();

    /*
     * Question 5
     */
   /*cout<<" Number of entries of file : "<< test.numberEnter(absolutePath)<<std::endl;

    for (int i = 0; i < hash_size; ++i) {
        cout<<" Number of entries on "+ std::to_string(i)+" row of hash table : "<< test.getNumberItemByLine(absolutePath,i) << std::endl;

    }

    test.generateFile(workPath+"/list_students.csv",workPath+"/file.dat");
*/
    /**
     * Question 6
     */
    /*
    Student *filter= new Student("" , "MARLIN" , "");
    Student *filter2= new Student("" , "PIRANDA" , "");
    std::vector<Student> res,res1;
    cout <<"The number of item that match in first case: "<< test.find(filter, res) <<std::endl;
    for ( int i = 0; i < res.size(); ++i )
        cout << res.at(i) << std::endl;
    cout <<"The number of item that match in second case: "<< test.find(filter2, res1) <<std::endl;
    for ( int i = 0; i < res1.size(); ++i )
        cout << res1.at(i) << std::endl;
    */


    return 0;
}

//
// Created by abou on 23/09/2019.
//

#ifndef HASHTABLE_MYFACTORY_H
#define HASHTABLE_MYFACTORY_H

#include <array>
#include <iostream>
#include "List.h"
#include "Student.h"
#include <fstream>
#include "constants.h"
#include <vector>

using namespace std;


template<class T>
class MyFactory {
    std::array<T *, hash_size> hash_table;
    string filename = "";
public:

    MyFactory() {
        init();
    }

    MyFactory(std::string fileName) {

        filename = fileName;
        init();
        T *tmp;
        /**
         * @details to get exception in error file name
         */
        try {
            ifstream input(fileName);
            string result;
            string line;
            string limeter = ";";
            size_t found;
            int i = 0;
            while (std::getline(input, line, '\n')) {
                found = 0;

                found = line . find(limeter);
                string surname = line . substr(0, found);
                line . erase(0, found + 1);
                found = line . find(limeter);
                string name = line . substr(0, found);
                line . erase(0, found + 1);
                List<Student> *nw = new List<Student>(new Student(name, surname, line));

                insert(nw);
            }

        }   /**
 *
 */
        catch (std::exception const &e) {

            cout << e . what() << endl;
        }

    }

    void init() {
        for (int i = 0; i < hash_size; ++i) {
            hash_table[i] = nullptr;
        }
    };

    /**
     *
     * @param fileName csv file
     * @return the number of entries in this file
     */
    int numberEnter(std::string fileName) {
        string line;
        ifstream input(fileName);
        int i = 0;
        while (std::getline(input, line, '\n')) {
            i++;

        }
        return i;

    };

    /**
     *
     * @param fileNameinput file which we want to count a rows
     * @param fileNameOuput file that will be created
     */
    static void generateFile(string fileNameinput, string fileNameOuput) {
        ofstream myfile;
        myfile.open(fileNameOuput);
        /* X is a number of each row and Y is a number of item on each row*/
        myfile << "#X   Y " << endl;


        for (int i = 0; i < hash_size; ++i) {
            myfile << i << "    " << getNumberItemByLine(fileNameinput, i) << std::endl;

        }

        myfile . close();

    }
    //TODO surcharge of method to allow usage of variable local fileName.

    /**
     *
     * @param fileName the file's name that we want to get the distribution in a line of hash table (absolute path)
     * @param lineInHashTable the number of line that we will like to get the count of item that will be store there.
     * @return the number of item that will be store there
     */


    static int getNumberItemByLine(std::string fileName, int lineInHashTable) {

        ifstream input(fileName);
        string line;
        string limeter = ";";
        size_t found;
        int hash = 0;
        int i = 0;
        while (std::getline(input, line, '\n')) {
            found = 0;
            found = line . find(limeter);
            string name = line . substr(0, found);
            line . erase(0, found + 1);
            found = line . find(limeter);
            //TODO with static method get hash code will be more efficient
            for (char a: line . substr(0, found)) {
                hash += (int) a;
            }
            if (hash % hash_size == lineInHashTable) {
                i++;
            }
        }
        return i;

    };

    /**
     * @details The complexity in worst case of this process is O(1)
     * @param s in our case, s is object of List<Student>
     * @return the position where the item will be store
     */

    int insert(T *s) {
        int position = int(*s);
        if (hash_table[position] == nullptr) {
            hash_table[position] = s;
        } else {

            T *tmp;
            tmp = hash_table[position];
            hash_table[position] = s;
            s -> next = tmp;
        }
        return position;
    };

    /**
     *  @details The complexity in worst case of this process is O(1)
     * @param s here s in a pointer of object of type Student, i found it necessary to allows to insert directly a Student object without use List<>
     * @return
     */
    int insert(Student *s) {
        T *t = new T(s);
        int position = int(*t);
        if (hash_table[position] == nullptr) {
            hash_table[position] = t;
        } else {

            T *tmp = new T(s);
            tmp = hash_table[position];
            hash_table[position] = t;
            t -> next = tmp;
        }
        return position;
    };

    /**
 * @details the function to display all of item that stored in hash table
 * @paragraph to better understand this function, let go in Class List where we can found the overriding of opertor <<
 * @paragraph to display all of item stored in each list
 */
    void print() {
        auto cht = hash_table . begin();
        int n = 0;
        while (cht != hash_table . end()) {

            if (*cht == nullptr) {
                cout << "[" << n++ << "] empty" << endl;
            } else {
                std::cout << "[" << n++ << "]" << *(*cht) << std::endl;
            }
            cht++;
        }
    };


    /**
     *
     * @param filter is object of class List<T>
     * @param res vector with all item that match the condition
     * @return number of item that math the condition
     */
    int find(T *filter, std::vector<Student> &res) {


        int position = int(*filter);
        return hash_table[position]?hash_table[position] -> find(filter, res):0;
    };
    int find(Student *filter, std::vector<Student> &res) {
        T *tmp= new T(filter);
        int position = int(*tmp);
        return hash_table[position]?hash_table[position] -> find(tmp, res):0;
    };

    /**
     *
     * @param filter is object of class List<Student>
     * @return true if found else false
     */
    bool find(T *filter) {
        int position = int(*filter);
        return hash_table[position] -> find(filter);

    };

    /**
     *
     * @param filter is object of class Student
     * @return true if found else false
     */
    bool find(Student *filter) {
        int position = int(*filter);
        T *tmp = new T(filter);
        return hash_table[position] -> find(tmp);

    };

    int insertOld(T *s) {
        int position = int(*s);

        if (hash_table[position] == nullptr) {
            hash_table[position] = s;

        } else {
            hash_table[position] -> insert(s -> value);

        }
        return position;
    };
};


#endif //HASHTABLE_MYFACTORY_H

//
// Created by abou on 28/09/2019.
//

#ifndef HASHTABLE_CONSTANTS_H
#define HASHTABLE_CONSTANTS_H
/**
 * @param workPath is the path of current folder of project.
 * @attention initialize our environment before start test the code
 */
const int hash_size=20;
//TODO function that can get path of current folder independent of the operating system
const std::string workPath="/home/abou/Bureau/COURSM1IOT/AdvancedAlgorithms/Exercice/2.3ListandHashtable/hashTableList/";


#endif //HASHTABLE_CONSTANTS_H

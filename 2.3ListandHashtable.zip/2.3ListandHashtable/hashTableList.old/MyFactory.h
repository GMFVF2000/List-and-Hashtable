//
// Created by abou on 23/09/2019.
//

#ifndef HASHTABLE_MYFACTORY_H
#define HASHTABLE_MYFACTORY_H

#include <array>
#include <iostream>
#include "List.h"
#include "Student.h"
#include <fstream>
#include "constants.h"
#include <vector>
using namespace std;


template <class T>
class MyFactory {
    std::array<T*, hash_size>  hash_table;
    string filename="";
    public:

    MyFactory(){
        init();
}

    MyFactory(std::string fileName){

        filename=fileName;
        init();
        T * tmp;
        try {
            ifstream input(fileName);
            string result;
            string line;
            string limeter=";";
            size_t found;
            int i=0;
            while (std::getline(input , line,'\n')) {
                found=0;

                found=line.find(limeter);
                string name = line.substr(0, found);
                line.erase(0,found+1);
                found=line.find(limeter);
                string surname= line.substr(0,found);
                line.erase(0,found+1);
                List<Student> *nw= new List<Student>(new Student(name, surname, line));

                insertO(nw);
            }

        }   /**
 *
 */
            catch(std::exception const& e){

                cout<< e.what() <<endl;
            }

    }

    void init(){
        for (int i = 0; i < hash_size; ++i) {
            hash_table[i]=nullptr;
        }
};
    int numberEnter(std::string fileName){
        string line;
        ifstream input(fileName);
        int i=0;
        while (std::getline(input , line,'\n')) {
            i++;

        }
        return i;

    };
    /**
     *
     * @param fileNameinput file which we want to count a rows
     * @param fileNameOuput file that will be created
     */
    static void generateFile(string fileNameinput, string fileNameOuput){
        ofstream myfile;
        myfile.open(fileNameOuput);
        myfile << "#X   Y "<<endl;


        for (int i = 0; i <hash_size ; ++i) {
            myfile << i << "    "<<getNumberItemByLine(fileNameinput,i) << std::endl;

        }

        myfile.close();

    }
    //TODO surcharge of method to allow usage of variable local fileName.




    static int getNumberItemByLine(std::string fileName,int lineInHashTable){

        ifstream input(fileName);
        string line;
        string limeter = ";";
        size_t found;
        int hash=0;
        int i=0;
        while (std::getline(input , line,'\n')) {
            found=0;
            found=line.find(limeter);
            string name = line.substr(0, found);
            line.erase(0,found+1);
            found=line.find(limeter);
        //TODO with static method get hash code will be more efficient
            for (char a: line.substr(0,found)) {
                hash += (int) a;
            }
                if (hash%hash_size==lineInHashTable){
                    i++;
                }
        }
        return i;

    };
    int insert(T* s){
        int position = int(*s);

        if(hash_table[position]== nullptr){
            hash_table[position]=s;

        }else
        {
            hash_table[position]->insert(s->value);

        }
        return position;
    };
    int insertO(T* s){
        int position = int(*s);

        if(hash_table[position]== nullptr){
            hash_table[position]=s;

        }else
        {

            hash_table[position]->insert(s->value);
            T *tmp;
            tmp=hash_table[position];
            hash_table[position]=s;
            s->next=tmp;
        }
        return position;
    };

    /*
    void print(){

        auto cht = hash_table.begin();
        int n=0;
        while(cht!= hash_table.end()){

            if(*cht== nullptr){
                cout<< "["<<n++<<"] empty"<<endl;
            }else{
                std::cout << "[" << n++ << "]" << *(*cht) <<std::endl;

            }
            cht++;
        }
    };
*/

void print(){

        auto cht = hash_table.begin();
        int n=0;
        while(cht!= hash_table.end()){

            if(*cht== nullptr){
                cout<< "["<<n++<<"] empty"<<endl;
            }else{
               std::cout << "[" << n++ << "]" << *(*cht) <<std::endl;
            }
            cht++;
        }
    };


    bool find( T *filter ) {
        int position = int( *filter );
        return hash_table[ position ]->find(filter);

    };

    bool find( Student *filter ) {
        int position = int( *filter );
        T *tmp=new T(filter);

        return hash_table[ position ]->find(tmp);

    };

   int find(T *filter, std::vector<Student> &res ) {

        //TODO Implement this part of

       int position = int( *filter );


       return hash_table[ position ]->find(filter,res);
    };


};


#endif //HASHTABLE_MYFACTORY_H

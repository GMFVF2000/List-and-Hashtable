#include <iostream>
#include "Student.h"
#include "MyFactory.h"
#include "List.h"

int main() {
    string absolutePath=  workPath+ "/list_students.csv";
  MyFactory<List<Student>> test(absolutePath);
    //MyFactory<List<Student>> test;

   //test.generateFile(workPath+"/list_students.csv",workPath+"/file.dat");


    //For test isertion without file. In other words simple process of insertion
        List<Student> *nw= new List<Student>(new Student("SANOU","Issiaka","Professeur"));
        test.insertO(nw);

        nw= new List<Student>(new Student("Frederic","LASSABE","PhD"));
        test.insertO(nw);

        nw= new List<Student>(new Student("Philippe","CANALDA","PhD"));
        test.insert(nw);


        nw= new List<Student>(new Student("Kane","Issiaka","Professeur"));
        test.insertO(nw);

      /*  nw= new List<Student>(new Student(" Benoit " , "PIRANDA" , "PhD"));
        test.insert(nw);

        nw= new List<Student>(new Student(" Benoit " , "PIRANDA" , "PhD"));
        test.insert(nw);
*/
        nw= new List<Student>(new Student(" Abou " , "PIRANDA" , "PhD"));
        test.insert(nw);
       /* std::vector<Student> res;
    cout << test.find(nw,res);
   for(int i=0; i<res.size();++i)
    cout<<res.at(i).surname<< std::endl;
*/
       test.print();


    return 0;
}

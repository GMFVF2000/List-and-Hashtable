//
// Created by abou on 28/09/2019.
//

#ifndef HASHTABLE_CONSTANTS_H
#define HASHTABLE_CONSTANTS_H

const int hash_size=20;
const std::string workPath="/home/abou/Bureau/COURSM1IOT/AdvancedAlgorithms/Exercice/2.3ListandHashtable/hashTableList";


#endif //HASHTABLE_CONSTANTS_H

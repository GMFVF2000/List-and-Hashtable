//
// Created by abou on 28/09/2019.
//
/**
 * Here i will store all of constants
 */
#ifndef HASHTABLE_CONSTANT_H

const int hash_size=20;


#define HASHTABLE_CONSTANT_H

#endif //HASHTABLE_CONSTANT_H

#include <iostream>
#include "Student.h"
#include "MyFactory.h"

int main() {

    MyFactory<Student> test;


    test.insert( new Student( "Benoit", "PIRANDA", "PhD" ));
    test.insert( new Student( "Philippe", "CANALDA", "PhD" ));
    test.insert( new Student( "Abdallah", "MAKHOUL", "PhD" ));
    test.insert( new Student( "Oumaya", "BAALA", "PhD" ));
    test.insert( new Student( "Frederic", "LASSABE", "PhD" ));
    test.insert(new Student("Francois" , "SPIES" , "PhD") );
    test.insert(new Student("Julien" , "BOURGEOIS" , "PhD") );
    test.print();


    if(test.find(new Student("Francois" , "SPIES" , "PhD"))){
        cout<< "I find it" <<endl;
    }else
    {
        cout << "I don't find it"<< endl;
    }


    return 0;
}
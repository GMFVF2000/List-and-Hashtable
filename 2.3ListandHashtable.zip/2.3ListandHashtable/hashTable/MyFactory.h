//
// Created by abou on 23/09/2019.
//

#ifndef HASHTABLE_MYFACTORY_H
#define HASHTABLE_MYFACTORY_H

#include <array>
#include <iostream>
#include "constant.h"


using namespace std;


template <class T>
class MyFactory {
   std::array<T*, hash_size>  hash_table;
public:
    /**
     * default constructor of my class
     */
    MyFactory(){
        init();
}

    /**
     * function to initialize all cell of my array to null pointer.
     */
    void init(){
        for (int i = 0; i < hash_size; ++i) {
            hash_table[i]=nullptr;
        }
};

    /**
     *
     * @param s generic class to insert into MyFactory
     * @return true if insertion is succeful else return false
     */
    bool insert(T* s){
        int position = int(*s);
        s->hash_value=position;
        if(hash_table[position]== nullptr){
            hash_table[position]=s;
            return true;
        }else
        {
            std::cerr <<"Not an empty space"<< std::endl;
            return false;
        }
    };








public:
    /**
     * function which display all items of out hash table
     */
    void print(){

        auto cht = hash_table.begin();
        int n=0;
        while(cht!= hash_table.end()){

            if(*cht== nullptr){
                cout<< "["<<n++<<"] : empty"<<endl;
            }else{

                std::cout << "[" << n << "] : " << *(*cht) <<std::endl;
                n++;
            }
            cht++;
        }
    };

    /**
     *
     * @param filter is a pointer on a generic class' object
     * @return true if it finds a item else false
     */
    bool find(T* filter){
        int position = int(*filter);

        return hash_table[position] != nullptr && *filter == *hash_table[position];
    };

};


#endif //HASHTABLE_MYFACTORY_H

//
// Created by abou on 23/09/2019.
//

#ifndef HASHTABLE_STUDENT_H
#define HASHTABLE_STUDENT_H


#include <string>
#include "constant.h"


class Student {
public:
        std::string name;
        std::string surname;
        std::string group;
        unsigned int hash_value;
public :
    Student (const std::string &pname, const std::string &psurname, const std::string &pgroup)
    :name(pname),surname(psurname),group(pgroup){
}
    Student ( const std::string &psurname, const std::string &pgroup)
            :surname(psurname),group(pgroup){

    }

    operator int() const
    {
    int hash=0;
    for(char a: surname){
        hash+= (int) a;
    }
    return hash%hash_size;
    }

    int calculsHash(){
    int hash=0;
    for(char a:surname)
        hash+=int(a);
        return hash%hash_size;
}

    friend std::ostream& operator << ( std::ostream &out, const Student &p){
    out << p.name+" "+p.surname+" "+p.group + " "+"("+std::to_string(p.hash_value)+")";
    return out;
    }

    /**
     * @details getter of variable name
     * @return name
     */
    const std::string &getName() const {
        return name;
    }
    /**
     * @details getter of variable surname
     * @return surname
     */
    const std::string &getSurname() const {
        return surname;
    }
    /**
     * @details gettr of variable group
     * @return group
     */
    const std::string &getGroup() const {
        return group;
    }

    int getHashValue() const {
        return hash_value;
    }

    void setName(const std::string &name) {
        Student::name = name;
    }

    void setSurname(const std::string &surname) {
        Student::surname = surname;
    }

    void setGroup(const std::string &group) {
        Student::group = group;
    }

    void setHashValue(int hashValue) {
        hash_value = hashValue;
    }

};
/**
 *Overridding of operator == on Student class;
 * @param a adress of a Student elment
 * @param b address of a Student
 * @return true if the surnames are same
 */
bool operator==(Student &a, Student &b) {
        if (a.surname==b.surname)
            return true;
        return false;
}

#endif //HASHTABLE_STUDENT_H

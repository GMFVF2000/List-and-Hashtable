#include <iostream>
#include "Node.h"
#include "BST_Window.h"
#include <vector>
#include <glutWindow.h>

//using namespace std;
int main(int argc, char **argv ) {
    std::cout << "Hello, World!" << std::endl;


    //  BST *root= new BST(16, nullptr, nullptr);
/*
    BST *root;
    BST *node1 = new BST(9);
    BST *node2= new BST(14);
    node1=new BST(11 , node1,node2);
    node2= new BST(6, new BST(4),new BST(7));
    node1=new BST(8,node2,node1);
    node2=new BST(31, nullptr, nullptr);
    node2=new BST(25, new BST(21),node2);
    root=new BST(16,node1,node2);
*/

 //   Node *root= new Node(16, nullptr, nullptr);
    /*
    root->insert(14);
    root->insert(9);
    root->insert(6);
    root->insert(4);
    root->insert(8);
    root->insert(31);
    root->insert(25);
    root->insert(16);
*/
  //  int a[]={14,9,6,4,8,31,25,16};
    //root->insert(a);

    //cout <<"La valeur est"<<root->findKey(25)->key;

  /*  if(root->remove(14))
        cout <<"oui ";
    else
        cout <<"Non";
*/
  //  root->print();
    /*
    int h=root->getHeight();
    std::vector < std::pair<int,int> > Nh;
     for (int j = 0; j < h; ++j) {
     Nh.push_back(std::make_pair(root->nbChildrenAtLevel(j),0) );
    }
    root->placeNode(Nh, root->getHeight());
*/

  /*  root->print();
    if(root->findKey(444)){
        cout<< "Salut la famille";
    }else
    {
        cout<< "Salut la familleeee";
    }
    */
     //BST_Window fenetre ("BST",root,argc,argv);
/*
    for (int i = 0; i < h; ++i) {
        std::cout<< "Level " << i << " : " << root->nbChildrenAtLevel(i)<<std::endl;

    }
  */
    //std::cout << "number of nodes =" << root->nbrNodes()<<std::endl;
      //          std::cout <<"The height od bst "<<  root->getHeight()<<std::endl;

      //fenetre.start();
      return 0;
}
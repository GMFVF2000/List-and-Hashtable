//
// Created by abou on 24/10/2019.
//

#include "BST.h"
BST::BST(Node *root) : root(root) {

}

bool BST:: findKey(int keyp)
{
    if(root->key < keyp)
        return root->rightChild != nullptr ? root->rightChild->findKey(keyp) : false;


    if(root->key > keyp)
        return root->leftChild != nullptr ? root->leftChild->findKey(keyp) : false;


    return true;
}

bool BST::isComplete() {
    {
        // return if tree is empty
        if (root == nullptr)
            return false;

        // create an empty queue and enqueue root node
        std::list<Node*> queue;
        queue.push_back(root);

        // pointer to store current node
        Node* front = nullptr;

        // flag to mark end of full nodes
        bool flag = false;

        // run till queue is not empty
        while (queue.size())
        {
            // pop front node from the queue
            front = queue.front();
            queue.pop_front();

            // if we have encountered a non-full node before and current node
            // is not a leaf, tree cannot be complete tree
            if (flag && (front->leftChild || front->rightChild))
                return false;

            // if left child is empty & right child exists, tree cannot be complete
            if (front->leftChild == nullptr && front->rightChild)
                return false;

            // if left child exists, enqueue it
            if (front->leftChild)
                queue.push_back(front->leftChild);

                // if current node is a non-full node, set flag to true
            else
                flag = true;


            // if right child exists, enqueue it
            if (front->rightChild)
                queue.push_back(front->rightChild);

                // if current node is a non-full node, set flag to true
            else
                flag = true;
        }

        return true;
    }
}
void BST::placeNode( std::vector<std::pair <int,int> > &Nh, int h){
    int H= Nh.size();

    cout<< "Taille vector: " <<Nh[3].second<< std::endl;


    root->x=800*((Nh[h].second+0.5)/Nh[h].first);
    root->y=800*(1-(h+0.5)/H);
    cout<< "X" <<root->x<< std::endl;
    cout<< "Y" <<root->y<< std::endl;

    //root->x=800*(Nh[h].second+0.5)/H;
    //root->y=800*(1-(h+0.5)/H);
    Nh[h]=std::make_pair(Nh[h].first,Nh[h].second+1);

    if(root->leftChild) root->leftChild->placeNode(Nh,h+1);
    if(root->rightChild) root->rightChild->placeNode(Nh,h+1);
}

int BST::getHeight(){
    return 1+ std::max( (root->leftChild ? root->leftChild->getHeight(): 0 ) , (root->leftChild?root->leftChild->getHeight(): 0 )) ;
}
int BST::nbrNodes() {

    return 1+(root->leftChild?root->leftChild->nbrNodes():0)+
           (root->rightChild?root->rightChild->nbrNodes():0);

}

int BST::nbChildrenAtLevel(int h) {

    if(h==0) return 1;
    else{
        return  (root->leftChild ? root->leftChild->nbChildrenAtLevel(h-1):0)+
                (root->rightChild ? root->rightChild->nbChildrenAtLevel(h-1):0);

    }

}

void BST::print() {
    if(root->leftChild) root->leftChild->print();
    std::cout << root->key << std::endl;
    if (root->rightChild) root->rightChild->print();
}

void BST::printCordinates() {
    if(root->leftChild) root->leftChild->printCordinate();
    std::cout << "Value of x: " << root->x << std::endl;
    std::cout << "Value of x: " << root->y << std::endl;
    if (root->rightChild) root->rightChild->printCordinate();
}

int BST::countnodes(Node *root)

{
    if(root != NULL)
    {
        countnodes(root->leftChild);
        count++;
        countnodes(root->rightChild);
    }
    return count;

}
bool BST::isBST() {
    if(root== nullptr){
        return 0;
    }
    if (root->leftChild != NULL && root->leftChild->key > root->key)
        return 0;
    if (root->rightChild != NULL && root->rightChild->key < root->key)
        return 0;
    if(root->leftChild!=NULL )
        if (!root->leftChild->isBST())
            return 0;
    if(root->rightChild!=NULL)if(!root->rightChild->isBST())
            return 0;
    return 1;
}
//
// Created by abou on 23/09/2019.
//

#ifndef BST_NODE_H
#define BST_NODE_H


#include <iostream>
#include <algorithm>
#include <vector>
#include <glutWindow.h>
#include <stack>


class Node {
    Node* parent;
public:
    int key;
    float x,y;

    Node* rightChild;
    Node* leftChild;
public:

   Node(int k):key(k),leftChild(nullptr),rightChild(nullptr),parent(nullptr){

    }

    int getKey() const {
        return key;
    }

    float getX() const {
        return x;
    }

    float getY() const {
        return y;
    }

    /**
     *
     * @param k
     * @param lc
     * @param rc
     */
    Node(int k, Node* lc, Node *rc){
        key=k;
        leftChild=lc;
        rightChild=rc;
        parent= nullptr;
        if(leftChild) leftChild->parent=this;
        if(rightChild) rightChild->parent=this;

    }
    /**
     * @brief the number of element of nodes is 1 (me) +
     * the number of left children +
     * the number of right children
     * @return the number of children
     */
    int nbrNodes(){
        return 1+(leftChild?leftChild->nbrNodes():0)+
                (rightChild?rightChild->nbrNodes():0);
    }

    void print(){
        if(leftChild) leftChild->print();
        std::cout << key << std::endl;
        if (rightChild) rightChild->print();
     }



    int getHeight(){
        /*to get it i can search the max value of children*/
        return 1+ std::max( (leftChild ? leftChild->getHeight(): 0 ) , (leftChild?leftChild->getHeight(): 0 )) ;
    }
    int nbChildrenAtLevel(int h){

        if(h==0) return 1;
        else{
            return  (leftChild ? leftChild->nbChildrenAtLevel(h-1):0)+
                    (rightChild ? rightChild->nbChildrenAtLevel(h-1):0);

        }
    }
    void placeNode( std::vector<std::pair <int,int> > &Nh, int h){
        int H= Nh.size();
        //Nh[h].first++;
        //x=800*(Nh[h].second+0.5)/H;
        // y=800*(1-(h+0.5)/H);

        x=800*((Nh[h].second+0.5)/Nh[h].first);
        y=800*(1-(h+0.5)/H);
        //cout<< "X" <<x<< std::endl;
        //cout<< "Y" <<y<< std::endl;
        Nh[h].second++;

        if(leftChild) leftChild->placeNode(Nh,h+1);
        if(rightChild) rightChild->placeNode(Nh,h+1);
    }

public:
    Node *getLeftChild() const {
        return leftChild;
    }

    Node *getRightChild() const {
        return rightChild;
    }

    Node *getParent() const {
        return parent;
    }
    bool isBST(){

        if (this->leftChild != NULL && this->leftChild->key > this->key)
            return 0;
        if (this->rightChild != NULL && this->rightChild->key < this->key)
            return 0;
           if(leftChild!=NULL )
                if (!leftChild->isBST())
                return 0;
            if(rightChild!=NULL)if(!rightChild->isBST())
                    return 0;
        return 1;
    }

    bool isFull(){

        if (this->leftChild == NULL && this->rightChild == NULL)
            return true;

        if ((this->leftChild) && (this->rightChild))
            return this->leftChild->isFull() && this->rightChild->isFull();

      return false;

    }

    bool isComplete(int d, int &end){
            std::stack<Node *> ens;
        return  false;


    }

    bool findKey(int keyp)
    {


        if(this->key < keyp)
            return rightChild != nullptr ? rightChild->findKey(keyp) : false;


        if(this->key > keyp)
            return leftChild != nullptr ? leftChild->findKey(keyp) : false;

        // just to delete the warming
        return true;
    }

    bool insert(int keyp){
       if(this->key < keyp)
            if (rightChild == nullptr)
            {
                Node *temp=new Node(keyp, nullptr, nullptr);
                this->rightChild=temp;
                return true;
            }else{
                return rightChild->insert(keyp);
            }
        if(this->key > keyp)
            if( leftChild == nullptr)
            {
                Node *temp=new Node(keyp, nullptr, nullptr);
                this->leftChild=temp;
                return true;
            }else{
                return leftChild->insert(keyp);
            }
 return false;
    }
    template <typename T,size_t N>
    bool insert(T (&tabKey)[N])
    {
    cout << N <<std::endl;

    for(auto tmp:tabKey){

        this->insert(tmp);

    }
        return true;
    }

    bool remove(int k ){
        Node * current= nullptr;
        Node * parent= nullptr;
        if(searchKey(k,current,parent))
        {


                if(current->rightChild== nullptr && current->leftChild== nullptr)
            {
                parent->leftChild->key==k?parent->leftChild = nullptr:parent->rightChild= nullptr;
            }
            return true;

        }
        else{
            return false;
        }
        //Case One
        // For remove the noed without children very easy. Clean the poi,ter forward this node and it's ok

        // Case two
        //For remove with a one child we must change the pointer to the child only

        //Case three
        //I search the miminum for a right subtree
        //Find min in right-subtree
        //Copy the value in targetted node
        //Delete duplicate from right-subtree


        //Case three bis
        //Find max in left-subtree
        //Copy the value in targetted node
        //Delete duplicate from left-subtree
    return true;
    }

    bool searchKey(int keyp, Node * parent , Node * current){



        if(this->key < keyp) {
            parent = this;
            return rightChild != nullptr ? rightChild->searchKey(keyp, parent, current) : false;
        }

        if(this->key > keyp) {
            parent = this;

            return leftChild != nullptr ? leftChild->searchKey(keyp, parent, current) : false;
        }
        current=this;
        return true;





/*
        parent= nullptr;
            current=this;
            while(keyp!=current->key)
            {
                if(this->key > keyp){
                    if (this->leftChild!= nullptr)
                    {
                        cout << "Je suis à guache "<< std::endl;
                        parent=this;
                        current=this->leftChild;

                    }else
                    {
                        return false;
                    }

                }

                if(this->key < keyp){
                    if (this->rightChild!= nullptr)
                    {
                        cout << "Je suis à droite"<<std::endl;
                        parent=this;
                        current=this->rightChild;
                    }else
                    {
                        return false;
                    }

                }

            }
    return true;

    */
    }







public :static Node* deleteNode(Node* root, int value) {
       /* if (root == nullptr)
            return nullptr;*/
        if (root->key > value) {
            root->leftChild = deleteNode(root->leftChild, value);
        } else if (root->key < value) {
            root->rightChild = deleteNode(root->rightChild, value);

        } else {
            // if nodeToBeDeleted have both children
            if (root->leftChild != nullptr && root->rightChild != nullptr) {
                Node* temp = root;
                // Finding minimum element from right
                Node *minNodeForRight = minimumElement(temp->rightChild);
                // Replacing current node with minimum node from right subtree
                root->key = minNodeForRight->key;
                // Deleting minimum node from right now
                deleteNode(root->rightChild, minNodeForRight->key);

            }
                // if nodeToBeDeleted has only left child
            else if (root->leftChild != nullptr) {
                root = root->leftChild;
            }
                // if nodeToBeDeleted has only right child
            else if (root->rightChild != nullptr) {
                root = root->rightChild;
            }
                // if nodeToBeDeleted do not have child (Leaf node)
            else
                root = nullptr;
        }
        return root;
    }


public :static Node* minimumElement(Node* root) {
        if (root->leftChild == nullptr)
            return root;
        else {
            return minimumElement(root->leftChild);
        }
    }

public :static Node* maxminumElement(Node* root) {
        if (root->rightChild == nullptr)
            return root;
        else {
            return maxminumElement(root->rightChild);
        }
    }


    void printCordinate() {

            if(leftChild) leftChild->printCordinate();
            std::cout << "Value of x: " << x << std::endl;
            std::cout << "Value of y: " << y << std::endl;
            if (rightChild) rightChild->printCordinate();

    }
};


#endif //BST_NODE_H

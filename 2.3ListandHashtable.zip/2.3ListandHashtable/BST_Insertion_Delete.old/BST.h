//
// Created by abou on 24/10/2019.
//

#ifndef BST_BST_H
#define BST_BST_H


#include "Node.h"
#include <queue>
#include <list>

class BST {
public:
    Node *root;
    int count=0;
public:
    BST(Node *root);
    bool findKey(int keyp);
    bool isComplete();
    void placeNode( std::vector<std::pair <int,int> > &Nh, int h);
    int getHeight();
    int nbrNodes();
    int nbChildrenAtLevel(int h);
    void print();
    void printCordinates();
    int countnodes(Node *root);
    bool isBST();
};


#endif //BST_BST_H
